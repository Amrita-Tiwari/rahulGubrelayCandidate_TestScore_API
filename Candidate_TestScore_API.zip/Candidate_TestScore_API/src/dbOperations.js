const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbConfig = {
    host: "localhost",
    user: "root",
    password: "Root@123",
    database: "CandidateCrudTestScore",
  };

let addCandidate = async (input) => {
    try {
        console.log(input);

        const connection = mysql.createConnection(dbConfig);
        //console.log(input);

        await connection.connectAsync();
        console.log(input);

        let sql = "INSERT INTO Candidate(id ,name,email) VALUES(?,?,?)";
        console.log(input);

        console.log(input.id);
        console.log(input.name);
        console.log(input.email);
        
        await connection.queryAsync(sql, [
            input.id,
            input.name,
            input.email,
        ]);
        await connection.endAsync();
    } catch (err) {
        console.log(err);
    }
};

let addTestScore = async (input) => {
    try {
        console.log(input);

        const connection = mysql.createConnection(dbConfig);
        //console.log(input);

        await connection.connectAsync();
        console.log(input);

        let sql = "INSERT INTO test_score(id ,first_round,second_round,third_round) VALUES(?,?,?,?)";
        console.log(input);

        console.log(input.id);
        console.log(input.first_round);
        console.log(input.second_round);
        console.log(input.third_round);
        
        await connection.queryAsync(sql, [
            input.id,
            input.first_round,
            input.second_round,
            input.third_round,
        ]);
        await connection.endAsync();
    } catch (err) {
        console.log(err);
    }
};

let showHighest = async (iput) => {
    const connection = mysql.createConnection(dbConfig);
  
    await connection.connectAsync();
  
    let sql = "SELECT max(first_round), max(second_round),max(third_round) from test_score";
  
    let results = await connection.queryAsync(sql);
    console.log(results);
    await connection.endAsync();
    return results;
  };

  let showAverage = async (iput) => {
    const connection = mysql.createConnection(dbConfig);
  
    await connection.connectAsync();
  
    let sql = "select avg(first_round),avg(second_round),avg(third_round) from test_score;";
  
    let results = await connection.queryAsync(sql);
    console.log(results);
    await connection.endAsync();
    return results;
  };

module.exports = {
    addCandidate,
    addTestScore,
    showHighest,
    showAverage,
};