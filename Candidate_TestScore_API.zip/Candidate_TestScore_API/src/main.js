const express = require("express");
const db = require("./dbOperations");

const app = express();
app.use(express.json());

app.post("/addcan", async (req, res) => {
    console.log("Main Method Started...............");
      try {
        const input = req.body;
        console.log(input);
        await db.addCandidate(input);
        res.json({ message: "Successfully data inserted" });
      } catch (err) {
        res.json({ message: "failed !!!" });
      }
    });

    app.post("/addscore", async (req, res) => {
        console.log("Main Method Started...............");
          try {
            const input = req.body;
            console.log(input);
            await db.addTestScore(input);
            res.json({ message: "Successfully data inserted" });
          } catch (err) {
            res.json({ message: "failed !!!" });
          }
        });



 app.get("/showhigh", async (req, res) => {
            try {
              let results = await db.showHighest();
              res.json(results);
            } catch (err) {
              res.json({ message: "failure" });
            }
          });


          app.get("/showavg", async (req, res) => {
            try {
              let results = await db.showAverage();
              res.json(results);
            } catch (err) {
              res.json({ message: "failure" });
            }
          });

app.listen(3000);